function print() {
    var iframe = document.getElementById('choosefile');
    iframe.contentWindow.print();
}

// window.onload = function() {
//         var fileInput = document.getElementById('fileInput');
//         // var fileDisplayArea = document.getElementById('fileDisplayArea');
//
//         fileInput.addEventListener('change', function(e) {
//             var file = fileInput.files[0];
//             var textType = /text.*/;
//
//             if (file.type.match(textType)) {
//                 var reader = new FileReader();
//
//                 reader.onload = function(e) {
//                     fileDisplayArea.innerText = reader.result;
//                 }
//
//                 reader.readAsText(file);
//             } else {
//                 fileDisplayArea.innerText = "File not supported!"
//             }
//         });
// }

function readdata(){
  var fs = require('fs');
  var contents = fs.readFileSync('input.html').toString();
  console.log(contents); //esperamos por el resultado

}
// var fileid;
// function getfile(file) {
//   fileid=this.id;
//   console.log(fileid);
//
//
// }

function btntest()
{
    // window.location.href = "file:///D:/gayathri/fetchdata.html";
    console.log("sthuthy");
    // var s = document.getElementById('choosefile');
    // console.log("stt",s);
}
function choosepath(){
  var data=document.getElementById('choosefile').contentWindow.print();
  console.log(data);
}
